int main() {
	while (1) {
		textVGATest();
	}
	return 0;
}
